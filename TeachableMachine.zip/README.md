# TeachableMachine
play with Teachable Machine sample code


## Goal
Detect whether I am drinking a coffee or not.
